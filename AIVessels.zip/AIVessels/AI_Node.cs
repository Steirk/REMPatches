﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
[ExecuteInEditMode]
public class AI_Node : MonoBehaviour
{
    public List<AI_Node> SightLines;
    
    AI_Node_Controller controller;
    Vector3 lastpos;
    
    void Start()
    {
       
    }


  /*  void Update()
    {
        if (controller == null) { controller = GetComponentInParent<AI_Node_Controller>(); }
        if (lastpos != transform.position) { lastpos = transform.position; controller.updateSightLines = true; }

        if (Selection.Contains(this.gameObject)|| Selection.Contains(transform.parent.gameObject)) {
         
            foreach (var l in SightLines)
            {
                Debug.DrawLine(transform.position, l.transform.position, Color.cyan);
            }
        }

    }
  */
    public void UpdateZones(AI_Node[] otherNodes)
    {
        int lm = 1 << LayerMask.NameToLayer("Default") | 1 << LayerMask.NameToLayer("builder");
        RaycastHit target;
        foreach (AI_Node n in otherNodes)
        {
            if (n != this)
            {
                //transform.LookAt(n.transform.position);

                // int lm = 1 << LayerMask.NameToLayer("detection");
                if (Physics.Raycast(transform.position,(n.transform.position- transform.position), out target, Mathf.Infinity, lm, QueryTriggerInteraction.Collide))
                {
                   
                    if (target.collider.GetComponent<AI_Node>()) { target.collider.GetComponent<AI_Node>().SightLines.Add(this);  }
                  
                }
            }
        }

    }
}
