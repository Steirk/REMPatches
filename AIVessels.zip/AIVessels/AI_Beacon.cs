﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_Beacon : MonoBehaviour
{
    public Vessel_AiCore.TacticalStates beaconType;
    public string faction;
    public int squad = 0;
    public float radius = 10;
    public float lotierTime = 1;

  
  //  public enum BeaconType {Capture, Defend, Patrol, Tactical}
    public int index;

    void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(transform.position,radius);
    }
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
