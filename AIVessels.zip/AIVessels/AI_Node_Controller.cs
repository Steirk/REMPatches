﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[ExecuteInEditMode]
public class AI_Node_Controller : MonoBehaviour
{
    public GameObject node;
    public bool generateNodes;
    public bool updateSightLines;
    void Start()
    {
        
    }

    
    void Update()
    {
        if (updateSightLines) { updateSightLines = false; UpdateSightLines(); }
    }
    void UpdateSightLines() {
        AI_Node[] nodes = GetComponentsInChildren<AI_Node>();
        foreach (var n in nodes)
        {
            n.SightLines.Clear();
        }
        foreach (var n in nodes) {
            n.UpdateZones(nodes);
        }
    }
}
